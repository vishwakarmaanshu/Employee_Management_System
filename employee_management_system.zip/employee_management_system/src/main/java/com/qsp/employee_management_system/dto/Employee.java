package com.qsp.employee_management_system.dto;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;



@Entity
@Table(name = "employee_info")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "employeeId")
    private int id;
	
	@Column(name = "employeeName")
//	@NotNull(message="Name can't be null")
//	@NotBlank(message="Name can't be null")
	@NotEmpty(message="Name can't be empty")
    private String name;
	
	@Column(name = "employeePhone",unique = true)
	@Min(value=6000000000l)
	@Max(value = 9999999999l)
    private long phone;
	
	@Column(name = "employeeAddress")
//	@NotNull(message="address can't be null")
//	@NotBlank(message="address can't be null")
	@NotEmpty(message="address can't be empty")
    private String address;
	
	@Column(name = "employeeEmail",unique = true)
	@NotEmpty(message = "Email can't be empty")
	@Email(regexp = "[a-z0-9._$]+@[a-z]+\\.[a-z]{2,3}",message="Please enter the valid email")
    private String email;
	
	@Column(name = "employeePassword")
    private String password;
	
	@Column(name = "employeeSalary")
    private double salary;
	
	@Column(name = "employeeDesignation")
//	@NotNull(message="designation can't be null")
//	@NotBlank(message="designation can't be null")
	@NotEmpty(message="designation can't be empty")
    private String designation;
	
	@Column(name = "employeeGrade")
	private char grade;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public char getGrade() {
		return grade;
	}
	public void setGrade(char grade) {
		this.grade = grade;
	}
	
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", phone=" + phone + ", address=" + address + ", email="
				+ email + ", password=" + password + ", salary=" + salary + ", designation=" + designation + ", grade="
				+ grade + "]";
	}
	
	
}
